#include <stdio.h>

int main(){

	printf("\nint: %ld", sizeof(int));
	printf("\nfloat: %ld", sizeof(float));
	printf("\nlong: %ld", sizeof(long));
	printf("\ndouble: %ld", sizeof(double));
	printf("\nchar: %ld", sizeof(char));

	printf("\n\n");

	return 0;
}