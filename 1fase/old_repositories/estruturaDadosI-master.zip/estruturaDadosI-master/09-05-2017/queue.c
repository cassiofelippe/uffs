#include <stdio.h>

typedef struct {
	int id;
	int top;
}	queue;

void init_queue(queue *p){
	p -> top = -1;
}

void push(){
	malloc

}

int pop(){

}

int main(){
	int n;
	queue p;

	printf("\nInsira o id: ");
	scanf("%d", &n);

	// INICIA A PILHA EM -1 (VAZIA)
	init_queue(&p);

	queue id = malloc


	return 0;
}