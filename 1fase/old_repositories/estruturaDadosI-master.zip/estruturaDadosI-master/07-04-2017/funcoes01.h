// BIBLIOTECA CRIADA PARA O exerc01.c
/*int *searchMatrix(int *matriz, int *number); // *number APONTA O ENDEREÇO DE UM VALOR NA *matriz "searchMatrix"
void searchMatrix1(int *matriz, int *number, int *p); // *p APONTA O ENDERECO DO VALOR ARMAZENADO EM *number NA *matrix EM UMA MATRIZ SEM RETURN (POR REFERENCIA)*/