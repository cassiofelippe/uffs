#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAM 50

typedef struct product {
	int code;
	char name[TAM];
	float price;
}tp_product;

typedef struct pilha {
	tp_product *info;
	int top;
}tp_pilha;

void push(){

}

product pop(){
	
}

int main(){

}

// TRABALHO PILHA - MOODLE 02-05-2017