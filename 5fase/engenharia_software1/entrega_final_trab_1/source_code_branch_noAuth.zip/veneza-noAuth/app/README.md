# veneza

> Trabalho de Engenharia de Software I com a Empresa Ótica Veneza

## Build Setup

``` bash
yarn serve
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
