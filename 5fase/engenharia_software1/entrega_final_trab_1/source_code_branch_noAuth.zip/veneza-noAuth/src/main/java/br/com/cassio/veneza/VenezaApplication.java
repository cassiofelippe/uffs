package br.com.cassio.veneza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VenezaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VenezaApplication.class, args);
	}

}
