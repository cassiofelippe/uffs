package br.com.cassio.veneza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VenezaApplicationTests {

	@Test
	void contextLoads() {
	}

}
